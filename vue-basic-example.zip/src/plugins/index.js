import './dialog';
import vuetify from './vuetify';

export { vuetify };
