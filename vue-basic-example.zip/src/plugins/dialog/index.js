import Vue from 'vue';
import dialog from './dialog';

Vue.use(dialog);
