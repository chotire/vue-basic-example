<template>
  <v-main>
    <slot></slot>
  </v-main>
</template>

<script>
export default {
  name: 'PopupLayout',
};
</script>

<style lang="scss" scoped></style>
