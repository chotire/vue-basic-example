<template>
  <div>
    <img src="@/assets/images/logo-play.gif" width="1200" height="410" />
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
