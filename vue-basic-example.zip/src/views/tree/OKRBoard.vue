<template>
  <div class="mt-1">
    <div class="header d-flex">
      <div style="width: 45%" class="subject">Object / key Result / Work</div>
      <div style="width: 10%">완료일</div>
      <div style="width: 15%">담당</div>
      <div style="width: 30%">진행상태 (현재 <span class="text--disabled">전일대비</span>)</div>
    </div>
    <v-card class="rounded-0">
      <div class="root item d-flex">
        <div style="width: 45%" class="subject">
          <v-icon class="mr-2" small>mdi-infinity</v-icon>
          (O) (전략) 분기 내 투자 받을 수 있는 완벽한 분석과 계획을 만들자
          <div class="text-body-2 text--disabled ml-9">연결 (KR) 분기내 투자심의 진행</div>
        </div>
        <div style="width: 10%">6.30</div>
        <div style="width: 15%">abc group</div>
        <div style="width: 30%" class="d-flex">
          <v-progress-linear value="30" height="15"></v-progress-linear>
          <div style="width: 100px" class="ml-4">
            <div><span class="mr-1">30%</span><span class="text--disabled">+6%</span></div>
          </div>
        </div>
      </div>
      <v-divider></v-divider>
      <div class="item d-flex">
        <div style="width: 45%" class="subject"><span class="level-1">L</span>(KR) 그룹내 AI 도입 가능 시스템 5개 확보 및 손익 분석 완료</div>
        <div style="width: 10%">4.15</div>
        <div style="width: 15%">abc group</div>
        <div style="width: 30%" class="d-flex">
          <v-progress-linear value="22" height="15"></v-progress-linear>
          <div style="width: 100px" class="ml-4">
            <div><span class="mr-1">22%</span><span class="text--disabled">+1%</span></div>
          </div>
        </div>
      </div>
      <div class="item d-flex">
        <div style="width: 45%" class="subject"><span class="level-2">L</span>(W) 가나다라마바사아아아아아아</div>
        <div style="width: 10%">5.31</div>
        <div style="width: 15%">김한화</div>
        <div style="width: 30%" class="d-flex">
          <v-progress-linear value="22" height="15"></v-progress-linear>
          <div style="width: 100px" class="ml-4">
            <div><span class="mr-1">22%</span><span class="text--disabled">+1%</span></div>
          </div>
        </div>
      </div>
      <div class="item d-flex">
        <div style="width: 45%" class="subject"><span class="level-2">L</span>(W) 프로젝트를 수행하요</div>
        <div style="width: 10%">6.30</div>
        <div style="width: 15%">홍길동</div>
        <div style="width: 30%" class="d-flex">
          <v-progress-linear value="22" height="15"></v-progress-linear>
          <div style="width: 100px" class="ml-4">
            <div><span class="mr-1">22%</span><span class="text--disabled">+1%</span></div>
          </div>
        </div>
      </div>
      <div class="item d-flex">
        <div style="width: 45%" class="subject"><span class="level-1">L</span>(KR) 시스템 고도화 프로젝트 계획 수립 및 프로젝트 투입 인력 확보</div>
        <div style="width: 10%">5.31</div>
        <div style="width: 15%">abc group</div>
        <div style="width: 30%" class="d-flex">
          <v-progress-linear value="22" height="15"></v-progress-linear>
          <div style="width: 100px" class="ml-4">
            <div><span class="mr-1">22%</span><span class="text--disabled">+1%</span></div>
          </div>
        </div>
      </div>
      <div class="item d-flex">
        <div style="width: 45%" class="subject"><span class="level-2">L</span>(W) 확보 3건을 목표로한다</div>
        <div style="width: 10%">5.31</div>
        <div style="width: 15%">현미유</div>
        <div style="width: 30%" class="d-flex">
          <v-progress-linear value="46" height="15"></v-progress-linear>
          <div style="width: 100px" class="ml-4">
            <div><span class="mr-1">46%</span><span class="text--disabled">-</span></div>
          </div>
        </div>
      </div>
    </v-card>
    <v-card class="rounded-0">
      <div class="root item d-flex">
        <div style="width: 45%" class="subject">
          <v-icon class="mr-2" small>mdi-infinity</v-icon>
          (O) 분기의 예산 확보 계획을 만들자
          <div class="text-body-2 text--disabled ml-9">연결 (KR) 분기내 투자심의 진행</div>
        </div>
        <div style="width: 10%">6.30</div>
        <div style="width: 15%">abc group</div>
        <div style="width: 30%" class="d-flex">
          <v-progress-linear value="30" height="15"></v-progress-linear>
          <div style="width: 100px" class="ml-4">
            <div><span class="mr-1">30%</span><span class="text--disabled">+6%</span></div>
          </div>
        </div>
      </div>
      <v-divider></v-divider>
    </v-card>
  </div>
</template>

<script>
/**
 * 1. 데이터의 형태는?
 *   - OKR의 데이터가 Hierarchical 한 데이터인지?
 *     O 가 KR을 children 으로 표현할 수 있는 형태인지..
 *   - OKR의 depth 3단계 고정인지?
 * 2. O, KR, W 을 식별할 수 있는 값은?
 * 3. 기획서에 보면 KR 하위에 O 가 있는데.. 만약 이렇다면 정말 depth는 무한히 늘어날 수 있는 것인지
 */
export default {};
</script>

<style lang="scss" scoped>
.v-card {
  border: thin solid rgba(255, 255, 255, 0.12);
  margin-bottom: 10px;
}
.header {
  padding: 10px;
  width: 100%;
}
.subject {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  padding-right: 20px;
}
.root {
  cursor: pointer;
}
.item {
  margin: 10px;
}
.item div {
  margin: auto;
}
.level-1 {
  margin: 0 10px 0 24px;
}
.level-2 {
  margin: 0 10px 0 48px;
}
</style>
