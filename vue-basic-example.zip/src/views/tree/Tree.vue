<template>
  <div>
    <div class="d-flex">
      <v-btn small right class="mb-2" @click="expandAll(true)"><v-icon small>mdi-arrow-expand-vertical</v-icon></v-btn>
      <v-btn small right class="mb-2" @click="expandAll(false)"><v-icon small>mdi-arrow-collapse-vertical</v-icon></v-btn>
    </div>
    <!-- eslint-disable-next-line prettier/prettier -->
    <tree-data-table 
      :headers="headers" 
      :items="items" 
      item-key="id" 
      :open-all="openAll" 
      height="500"
      @click:row="highlight" 
      @contextmenu:row="showContextMenu" 
      dense hide-default-footer disable-pagination fixed-header single-select
    >
      <template #item.enabled="{ item }">
        <v-switch v-model="item.enabled" dense hide-details></v-switch>
      </template>
      <template #item.progress="{ value }">
        <v-progress-linear :value="value"></v-progress-linear>
      </template>
    </tree-data-table>

    <v-menu v-model="showMenu" :position-x="x" :position-y="y" z-index="10" absolute offset-y>
      <v-list dense>
        <v-list-item link>
          <v-list-item-title>Menu#1</v-list-item-title>
        </v-list-item>
        <v-list-item link>
          <v-list-item-title>Menu#2</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </div>
</template>

<script>
import TreeDataTable from '@/components/TreeDataTable';

export default {
  name: 'tree',
  components: {
    TreeDataTable,
  },
  data() {
    return {
      // TreeDataTable 컴포넌트는 headers에 expandable 이 true인 값을 기준으로
      // expand/collapse 기능을 추가하므로 원하는 컬럼에 expandable: true를 설정한다.
      headers: [
        { text: 'Department Name', value: 'name', sortable: false, width: '30%', expandable: true },
        { text: 'Department Head', value: 'head', sortable: false, width: '20%' },
        { text: 'Enabled?', value: 'enabled', sortable: false },
        { text: 'Progress', value: 'progress', sortable: false, width: '30%' },
        { text: 'Actions', value: 'actions', sortable: false },
      ],
      items: [],
      openAll: false,

      // context menu
      showMenu: false,
      x: 0,
      y: 0,
    };
  },
  created() {
    // TreeDataTable을 사용하기 위해서는 아래와 같이 계층적인(Hierarchical) 데이터가 요구되고
    // 또 그 데이터는 계층들 중 어떤 데이터가 Leaf 노드인지 표현되어야 한다.
    // 즉 TreeDataTable 이 필수적인 속성은 다음과 같다.
    // - children: 자식을 포함
    // eslint-disable-next-line prettier/prettier
    this.items = [
      {
        id: '1',
        name: 'Engineering',
        enabled: true,
        children: [
          { id: '1-1', name: 'Architecture Team', head: 'CHO YongSang', enabled: true, progress: 90 },
          {
            id: '1-2',
            name: 'Project Team',
            head: 'HONG GilDong',
            enabled: true,
            children: [
              { id: '1-2-1', name: 'OKR', head: 'KIM HyoungTae', enabled: true, progress: 20 },
              { id: '1-2-2', name: 'Web Chat', head: 'LEE DaeJin', enabled: false, progress: 32 },
              {
                id: '1-2-3',
                name: 'Open Source',
                head: 'LEE MongRyong',
                enabled: true,
                progress: 78,
                children: [
                  { id: '1-2-3-1', name: 'Back-End', head: 'CHO YongSang', enabled: true, progress: 30 },
                  { id: '1-2-3-2', name: 'Front-End', head: 'SUNG ChunHyang', enabled: true, progress: 48 },
                  { id: '1-2-3-3', name: 'Infra', head: 'BYUN Satto', enabled: false, progress: 0 },
                ],
              },
            ],
          },
          { id: '1-3', name: 'R&D', enabled: true, progress: 0 },
        ],
      },
      { id: '2', name: 'Marketing', enabled: true, children: [] },
    ];
  },
  methods: {
    expandAll(value) {
      this.openAll = value;
    },
    // { headers, opened, expanded, selected, item, select } arguments는 사용하고 싶은 것만 선택적으로 가능
    highlight(node, { selected, select }) {
      select(!selected);
    },
    // { headers, opened, expanded, selected, item, select } arguments는 사용하고 싶은 것만 선택적으로 가능
    showContextMenu(event) {
      event.preventDefault();
      this.x = event.clientX;
      this.y = event.clientY;
      this.showMenu = true;
    },
  },
};
</script>

<style lang="scss" scoped></style>
