import Dialog from './Dialog';
import { ALERT } from './type';
import { CONFIRM } from './type';
import { PROMPT } from './type';

export { Dialog, ALERT, CONFIRM, PROMPT };
