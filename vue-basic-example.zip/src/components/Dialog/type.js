export const ALERT = 'alert';
export const CONFIRM = 'confirm';
export const PROMPT = 'prompt';
