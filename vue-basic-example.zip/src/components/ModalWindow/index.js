import ModalWindow from './ModalWindow';

export default ModalWindow;
