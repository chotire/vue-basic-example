import TreeDataTable from './TreeDataTable';

export default TreeDataTable;
