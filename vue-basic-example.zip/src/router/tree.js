export default [
  {
    path: '/tree',
    name: 'tree',
    component: () => import(/* webpackChunkName: "tree" */ '@/views/tree/Tree.vue'),
  },
  {
    path: '/okr-board',
    name: 'okr-board',
    component: () => import(/* webpackChunkName: "tree" */ '@/views/tree/OKRBoard.vue'),
  },
];
